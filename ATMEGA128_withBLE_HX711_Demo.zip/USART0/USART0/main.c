#include <atmel_start.h>
#include "util/delay.h"
#include "hx711.h"

#define CLK_PIN PC1
#define DAT_PIN PC0

hx711_t loadcell;
volatile float weight;

#define  sbi(PORTX, BitX) (PORTX |= (1<<BitX))  // SET BIT
#define  cbi(PORTX, BitX) (PORTX &= ~(1<<BitX)) // CLEAR BIT

void putchar1_TX_int(unsigned long data);
unsigned long ReadCout(void);

//volatile unsigned long weight = 0;
volatile unsigned long offset = 0;
volatile int offset_flag = 0;

void putchar0(char c) // for Debug // 115200bps
{
    while(!(UCSR0A & 0x20));
    UDR0 = c;
}

void putchar1(char c) // for Bluetooth(HC-06) // 9600bps
{
    while(!(UCSR1A & 0x20));
    UDR1 = c;
}

int main(void)
{
    /* Initializes MCU, drivers and middleware */
    atmel_start_init();
    DDRC = 0b00000010; // C0(DOUT):input, C1(SCK):output

    // Initialize the hx711
    hx711_init(&loadcell, CLK_PIN, DAT_PIN);
    // Set the calibration coefficient
    hx711_coef_set(&loadcell, 1020); //500); //354.5); // read after calibration(ok-1020)
    // Tare the scale
    hx711_tare(&loadcell, 10);

    //int i;
    //char data[] = "Hello-Atmega128~\r\n";
    //char data1[] = "Hello-Bluetooth~\r\n"; // 0x0d, 0x0a

// config for USART0 (115200bps)
    UBRR0H = (8 >> 8); // '0'
    UBRR0L = 8;
    
    UCSR0B = (1 << TXEN0); // 0x08;
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00); // 0x06;

// config for USART1 (9600bps)
    UBRR1H = (103 >> 8);
    UBRR1L = 103;
    
    UCSR1B = (1 << TXEN1); // 0x08;
    UCSR1C = (1 << UCSZ11) | (1 << UCSZ10); // 0x06;
    
        
    /* Replace with your application code */
    while (1) {
        
        _delay_ms(500);
        // Read the weight
        weight = hx711_weight(&loadcell, 10);
        // Here you can add code to do something with the weight value
        
        //weight = ReadCout() / 4;
        putchar1_TX_int(weight);
        putchar1 ('\r');
        putchar1 ('\n');
        
        PORTB ^= 0x01;
        _delay_ms(500);
        
        //i = 0;
        // to usart0 (115200bps)
        //while ( data[i] != '\0') // NULL
        //putchar0(data[i++]);
        
        // to usart1 (9600bps)
        //i = 0;
        //_delay_ms(500);
        //while ( data1[i] != '\0') // NULL
        //putchar1(data1[i++]);
        
    }
}

unsigned long ReadCout(void)
{
    unsigned long sum = 0, count = 0, data1 = 0, data2 = 0;
    
    for (int j = 0; j < 10; j++)
    {
        sbi(PORTC, 0); // DOUT : 1
        cbi(PORTC, 1); // SCK : 0
        
        count = 0;
        
        while( (PINC & 0b00000001) == 0b00000001);
        
        for ( int i = 0; i < 24; i++)
        {
            sbi(PORTC, 1); // SCK:1
            count = count << 1;
            cbi(PORTC, 1); // SCK:0
            if ( (PINC & 0b00000001) == 0b00000001)
            count++;
        }
        sbi(PORTC, 1); // SCK:1
        count = count^0x800000;
        cbi(PORTC, 1); // SCK:0
        
        sum += count;
        //putchar0(sum); // for test
    }
    data1 = sum/10;
    
    if ( offset_flag == 0)
    {
        offset = data1;
        offset_flag = 1;
    }
    
    if (data1 > offset)
    data2 = data1 - offset;
    else
    data2 = 0;
    
    return data2;
}



void putchar1_TX_int(unsigned long data)
{
    unsigned long temp = 0;
    
    temp  = data / 10000;
    putchar0(temp+48);
    putchar1(temp+48);
    temp = (data%10000)/1000;
    putchar0(temp+48);
    putchar1(temp+48);
    temp = (data%1000)/100;
    putchar0(temp+48);
    putchar1(temp+48);
    temp = (data%100)/10;
    putchar0(temp+48);
    putchar1(temp+48);
    temp = data%10;
    putchar0(temp+48);
    putchar1(temp+48);
}
