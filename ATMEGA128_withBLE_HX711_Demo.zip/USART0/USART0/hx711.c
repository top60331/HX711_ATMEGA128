﻿/*
 * hx711.c
 *
 * Created: 2024-05-22 오전 5:49:46
 *  Author: top60
 */ 
#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include "hx711.h"
#include "hx711Config.h"

void hx711_lock(hx711_t *hx711); // 
void hx711_unlock(hx711_t *hx711); // 

// Replace the delay functions
#define hx711_delay_ms(x)    _delay_ms(x)
#define hx711_delay_us(x)    _delay_us(x)

// GPIO pin operations
#define HX711_CLK_PORT PORTC
#define HX711_CLK_DDR  DDRC
#define HX711_DAT_PIN  PINC
#define HX711_DAT_DDR  DDRC
#define HX711_DAT_PORT PORTC

#define SET_CLK()   (HX711_CLK_PORT |= (1<<hx711->clk_pin))
#define CLR_CLK()   (HX711_CLK_PORT &= ~(1<<hx711->clk_pin))
#define READ_DAT()  (HX711_DAT_PIN & (1<<hx711->dat_pin))

//#############################################################################################
void hx711_init(hx711_t *hx711, uint8_t clk_pin, uint8_t dat_pin)
{
    hx711_lock(hx711);
    hx711->clk_pin = clk_pin;
    hx711->dat_pin = dat_pin;

    // Set CLK pin as output
    HX711_CLK_DDR |= (1<<clk_pin);
    // Set DAT pin as input
    HX711_DAT_DDR &= ~(1<<dat_pin);

    SET_CLK();
    hx711_delay_ms(10);
    CLR_CLK();
    hx711_delay_ms(10);
    hx711_value(hx711);
    hx711_value(hx711);
    hx711_unlock(hx711);
}
//#############################################################################################
//void hx711_delay_us(void)
//{
//    _delay_us(1);
//}
//#############################################################################################
void hx711_lock(hx711_t *hx711)
{
    while (hx711->lock)
    hx711_delay_ms(1);
    hx711->lock = 1;
}
//#############################################################################################
void hx711_unlock(hx711_t *hx711)
{
    hx711->lock = 0;
}
//#############################################################################################
int32_t hx711_value(hx711_t *hx711)
{
    uint32_t data = 0;
    uint32_t startTime = 0; // Replace with appropriate timing function if needed
    while(READ_DAT() != 0)
    {
        hx711_delay_ms(1);
        if(startTime > 150) // Replace with appropriate timeout check
        return 0;
    }
    for(int8_t i=0; i<24 ; i++)
    {
        SET_CLK();
        _delay_us(1); // hx711_delay_us();
        CLR_CLK();
        _delay_us(1); // hx711_delay_us();
        data = data << 1;
        if(READ_DAT() != 0)
        data++;
    }
    data = data ^ 0x800000;
    SET_CLK();
    _delay_us(1); // hx711_delay_us();
    CLR_CLK();
    _delay_us(1); // hx711_delay_us();
    return data;
}
//#############################################################################################
int32_t hx711_value_ave(hx711_t *hx711, uint16_t sample)
{
    hx711_lock(hx711);
    int64_t ave = 0;
    for(uint16_t i=0 ; i<sample ; i++)
    {
        ave += hx711_value(hx711);
        hx711_delay_ms(5);
    }
    int32_t answer = (int32_t)(ave / sample);
    hx711_unlock(hx711);
    return answer;
}
//#############################################################################################
void hx711_tare(hx711_t *hx711, uint16_t sample)
{
    hx711_lock(hx711);
    int64_t ave = 0;
    for(uint16_t i=0 ; i<sample ; i++)
    {
        ave += hx711_value(hx711);
        hx711_delay_ms(5);
    }
    hx711->offset = (int32_t)(ave / sample);
    hx711_unlock(hx711);
}
//#############################################################################################
void hx711_calibration(hx711_t *hx711, int32_t noload_raw, int32_t load_raw, float scale)
{
    hx711_lock(hx711);
    hx711->offset = noload_raw;
    hx711->coef = (load_raw - noload_raw) / scale;
    hx711_unlock(hx711);
}
//#############################################################################################
float hx711_weight(hx711_t *hx711, uint16_t sample)
{
    hx711_lock(hx711);
    int64_t ave = 0;
    for(uint16_t i=0 ; i<sample ; i++)
    {
        ave += hx711_value(hx711);
        hx711_delay_ms(5);
    }
    int32_t data = (int32_t)(ave / sample);
    float answer =  (data - hx711->offset) / hx711->coef;
    hx711_unlock(hx711);
    return answer;
}
//#############################################################################################
void hx711_coef_set(hx711_t *hx711, float coef)
{
    hx711->coef = coef;
}
//#############################################################################################
float hx711_coef_get(hx711_t *hx711)
{
    return hx711->coef;
}
//#############################################################################################
void hx711_power_down(hx711_t *hx711)
{
    CLR_CLK();
    SET_CLK();
    hx711_delay_ms(1);
}
//#############################################################################################
void hx711_power_up(hx711_t *hx711)
{
    CLR_CLK();
}
//#############################################################################################
