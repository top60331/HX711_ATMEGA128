﻿/*
 * hx711Config.h
 *
 * Created: 2024-05-22 오전 5:50:38
 *  Author: top60
 */ 


#ifndef HX711CONFIG_H_
#define HX711CONFIG_H_

#define _HX711_USE_FREERTOS 0
#define _HX711_DELAY_US_LOOP 4



#endif /* HX711CONFIG_H_ */